package com.RestuarantAuth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestuarantAuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestuarantAuthApplication.class, args);
	}

}
